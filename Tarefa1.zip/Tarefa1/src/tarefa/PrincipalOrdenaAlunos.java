package tarefa;

import java.util.ArrayList;
import java.util.Collections;

/**
 * Classe Principal
 */
public class PrincipalOrdenaAlunos extends Util{
	private static int quantidade = 60000;
	
	 public static void main(String[] args) {
		 ArrayList<Aluno> alunosBolha = gerarAlunos(quantidade);
		 ArrayList<Aluno> alunosSelecao = gerarAlunos(quantidade);
		 ArrayList<Aluno> alunosInsercao = gerarAlunos(quantidade);
		 ArrayList<Aluno> alunosSort = gerarAlunos(quantidade);
		 
		 new Thread() {
	            public void run() {
	                Ordenacao.bolhaAluno(alunosBolha);
	                System.out.println("Feitooooo.... bolha");
	            }
	     }.start();
	     
	     new Thread() {
	            public void run() {
	                Collections.sort(alunosSort);
	                System.out.println("Feitooooo.... sort java");
	            }
	     }.start();
	     
	     new Thread() {
	            public void run() {
	                Ordenacao.insercaoAluno(alunosInsercao);
	                System.out.println("Feitooooo.... insercao");
	            }
	     }.start();
	     
	     new Thread() {
	            public void run() {
	                Ordenacao.selecaoAluno(alunosSelecao);
	                System.out.println("Feitooooo.... selecao");
	            }
	     }.start();
	     
	 }
}