package tarefa;
/**
 * Classe aluno para gerar objetos com nome e idade
 */
public class Aluno implements Comparable<Aluno>{
    String getNome;
    int getIdade;
      
    /**
     * Construtor
     * @param nome
     * @param idade
     */
    public Aluno(String nome, int idade) {
        this.getNome = nome;
        this.getIdade = idade;
    }  

    public String getNome() {
        return getNome;
    }
    public void setNome(String nome) {
        this.getNome = nome;
    }
    public int getIdade() {
        return getIdade;
    }
    public void setIdade(int idade) {
        this.getIdade = idade;
    }

    @Override
    public String toString() {
        return "Aluno [nome=" + getNome + ", idade=" + getIdade + "]";
    }

    @Override
    public int compareTo(Aluno outro) {
        int nomeCompare = this.getNome.compareTo(outro.getNome);
        
        if (nomeCompare == 0) {
            return Integer.compare(this.getIdade, outro.getIdade);
        }
        
        return nomeCompare;
    }
}