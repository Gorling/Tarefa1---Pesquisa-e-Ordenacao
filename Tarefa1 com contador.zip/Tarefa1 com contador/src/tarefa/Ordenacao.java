package tarefa;

import java.util.ArrayList;

/**
 * Classe com os metodos de ordenacao
 */
public class Ordenacao {
	public static long compBolha = 0;
	public static long compInsercao = 0;
	public static long compSelecao = 0;
	/**
	 * Metodo de ordenacao Bolha, que ordena uma lista de alunos e caso o nome dos alunos forem iguais, ordenara pelas idades
	 * @param lista
	 */
	public static void bolhaAluno(ArrayList<Aluno> lista) {
        Aluno aux;
        boolean houveTroca;
        int i;

        do {
            houveTroca = false;
            for (i = 0; i < lista.size() - 1; i++) {
                Aluno alunoAtual = lista.get(i);
                Aluno alunoProximo = lista.get(i + 1);
                
                compBolha += 1;

                if (alunoAtual.getNome().compareTo(alunoProximo.getNome()) > 0 ||
                    (alunoAtual.getNome().compareTo(alunoProximo.getNome()) == 0 && alunoAtual.getIdade() > alunoProximo.getIdade())) {
                    houveTroca = true;
                    aux = lista.get(i);
                    lista.set(i, lista.get(i + 1));
                    lista.set(i + 1, aux);
                }
            }
        } while (houveTroca);
    }
	
	/**
	 * Metodo de ordenacao Insercao, que ordena uma lista de alunos e caso o nome dos alunos forem iguais, ordenara pelas idades
	 * @param lista
	 */
	public static void insercaoAluno(ArrayList<Aluno> lista) {
        int i, j;
        Aluno aux;

        for (i = 1; i < lista.size(); i++) {
            aux = lista.get(i);
            j = i - 1;

            while (j >= 0) {
                Aluno alunoAtual = lista.get(j);

                int nomeCompare = alunoAtual.getNome().compareTo(aux.getNome());

                if (nomeCompare > 0 || (nomeCompare == 0 && alunoAtual.getIdade() > aux.getIdade())) {
                    lista.set(j + 1, alunoAtual);
                    compInsercao += 1;
                } else {
                	compInsercao += 1;
                    break;
                }
                j--;
            }
            lista.set(j + 1, aux);
        }
    }
	
	/**
	 * Metodo de ordenacao Selecao, que ordena uma lista de alunos e caso o nome dos alunos forem iguais, ordenara pelas idades
	 * @param lista
	 */
	public static void selecaoAluno(ArrayList<Aluno> lista) {
        int i, j, posMenor;
        Aluno aux;
        posMenor = 0;

        for (i = 0; i < lista.size() - 1; i++) {
            posMenor = i;

            for (j = i + 1; j < lista.size(); j++) {
                Aluno alunoAtual = lista.get(j);
                Aluno alunoMenor = lista.get(posMenor);

                int nomeCompare = alunoAtual.getNome().compareTo(alunoMenor.getNome());

                if (nomeCompare < 0 || (nomeCompare == 0 && alunoAtual.getIdade() < alunoMenor.getIdade())) {
                    posMenor = j;
                }
                compSelecao += 1;
            }

            if (posMenor != i) {
                aux = lista.get(i);
                lista.set(i, lista.get(posMenor));
                lista.set(posMenor, aux);
           }
       }
   }
}